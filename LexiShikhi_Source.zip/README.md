# LexiShikhi

Fresh Flutter starter for the LexiShikhi English-learning app.

## Included
- Bangla + English interface
- 8 learning modules / 120 offline topics
- Coin balance in the top-right corner
- Topic unlock system with persistent local storage
- Daily +5 coin bonus
- No automatic ads
- IAP/rewarded-ad config kept disabled until real Play Console / AdMob IDs are supplied
- App icon assets included
- Codemagic workflow builds both release APK and AAB
- Android compileSdk 36 / targetSdk 36 is applied automatically before build

## Build
Codemagic reads `codemagic.yaml`. The workflow creates/refreshes the Android platform with the installed stable Flutter SDK, applies API 36 settings and launcher icons, then builds both APK and AAB.

## Package name
Current generated Android package: `com.lexishikhi.lexishikhi`.
Do not upload the first Play Console release until you are happy with the package name, because changing it later creates a different app identity.

## Monetization
Real Play Billing and rewarded ads are intentionally off in this starter. Product IDs are listed as planned placeholders in `lib/config/monetization_config.dart`.


## DataPack v1 integrated
The original LexiShikhi_DataPack_v1 files are preserved under `assets/data/`. The app index `learning_content.json` is generated from those files and contains 369 topics across 11 modules. API 36 and launcher-icon build setup are unchanged.
