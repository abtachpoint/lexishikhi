from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
android = root / 'android'

kts = android / 'app' / 'build.gradle.kts'
groovy = android / 'app' / 'build.gradle'
path = kts if kts.exists() else groovy
if not path.exists():
    raise SystemExit('Android app Gradle file not found. Run flutter create first.')

text = path.read_text(encoding='utf-8')
if path.suffix == '.kts':
    text = re.sub(r'compileSdk\s*=\s*[^\n]+', 'compileSdk = 36', text)
    text = re.sub(r'targetSdk\s*=\s*[^\n]+', 'targetSdk = 36', text)
    text = re.sub(r'minSdk\s*=\s*[^\n]+', 'minSdk = 21', text)
else:
    text = re.sub(r'compileSdk(?:Version)?\s+[^\n]+', 'compileSdk 36', text)
    text = re.sub(r'targetSdk(?:Version)?\s+[^\n]+', 'targetSdk 36', text)
    text = re.sub(r'minSdk(?:Version)?\s+[^\n]+', 'minSdk 21', text)
path.write_text(text, encoding='utf-8')

manifest = android / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
if manifest.exists():
    m = manifest.read_text(encoding='utf-8')
    m = re.sub(r'android:label="[^"]*"', 'android:label="LexiShikhi"', m, count=1)
    manifest.write_text(m, encoding='utf-8')

print(f'Patched {path.name}: compileSdk=36, targetSdk=36, minSdk=21')
