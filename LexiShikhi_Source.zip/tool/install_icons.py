from pathlib import Path
import shutil

root = Path(__file__).resolve().parents[1]
source = root / 'tool' / 'android_icons'
res = root / 'android' / 'app' / 'src' / 'main' / 'res'

for density in ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']:
    src = source / f'mipmap-{density}' / 'ic_launcher.png'
    dst_dir = res / f'mipmap-{density}'
    dst_dir.mkdir(parents=True, exist_ok=True)
    if not src.exists():
        raise SystemExit(f'Missing icon: {src}')
    shutil.copy2(src, dst_dir / 'ic_launcher.png')

print('LexiShikhi launcher icons installed.')
