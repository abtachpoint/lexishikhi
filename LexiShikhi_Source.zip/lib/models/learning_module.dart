class LearningTopic {
  const LearningTopic({
    required this.id,
    required this.titleBn,
    required this.titleEn,
    required this.bodyEn,
    required this.tipBn,
    required this.cost,
  });

  final String id;
  final String titleBn;
  final String titleEn;
  final String bodyEn;
  final String tipBn;
  final int cost;

  factory LearningTopic.fromJson(Map<String, dynamic> json) {
    return LearningTopic(
      id: json['id'] as String,
      titleBn: json['titleBn'] as String,
      titleEn: json['titleEn'] as String,
      bodyEn: json['bodyEn'] as String,
      tipBn: json['tipBn'] as String,
      cost: (json['cost'] as num?)?.toInt() ?? 2,
    );
  }
}

class LearningModule {
  const LearningModule({
    required this.id,
    required this.titleBn,
    required this.titleEn,
    required this.descriptionBn,
    required this.descriptionEn,
    required this.topics,
  });

  final String id;
  final String titleBn;
  final String titleEn;
  final String descriptionBn;
  final String descriptionEn;
  final List<LearningTopic> topics;

  factory LearningModule.fromJson(Map<String, dynamic> json) {
    return LearningModule(
      id: json['id'] as String,
      titleBn: json['titleBn'] as String,
      titleEn: json['titleEn'] as String,
      descriptionBn: json['descriptionBn'] as String,
      descriptionEn: json['descriptionEn'] as String,
      topics: (json['topics'] as List<dynamic>)
          .map((item) => LearningTopic.fromJson(item as Map<String, dynamic>))
          .toList(),
    );
  }
}
