import 'package:flutter/material.dart';

import '../models/learning_module.dart';
import '../services/app_controller.dart';
import 'coins_screen.dart';
import 'topic_screen.dart';

class ModuleScreen extends StatelessWidget {
  const ModuleScreen({
    super.key,
    required this.controller,
    required this.module,
  });

  final AppController controller;
  final LearningModule module;

  @override
  Widget build(BuildContext context) {
    final isBn = controller.isBangla;
    return Scaffold(
      appBar: AppBar(
        title: Text(isBn ? module.titleBn : module.titleEn),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: Center(
              child: Text('🪙 ${controller.coins}'),
            ),
          ),
        ],
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: module.topics.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final topic = module.topics[index];
          final unlocked = topic.cost == 0 || controller.isUnlocked(topic.id);
          return Card(
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              leading: CircleAvatar(
                child: Text('${index + 1}'),
              ),
              title: Text(
                isBn ? topic.titleBn : topic.titleEn,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              subtitle: Text(
                unlocked
                    ? (isBn ? 'আনলক করা' : 'Unlocked')
                    : (isBn ? '${topic.cost} কয়েন লাগবে' : '${topic.cost} coins to unlock'),
              ),
              trailing: Icon(unlocked ? Icons.lock_open_outlined : Icons.lock_outline),
              onTap: () => _openTopic(context, topic),
            ),
          );
        },
      ),
    );
  }

  Future<void> _openTopic(BuildContext context, LearningTopic topic) async {
    if (topic.cost > 0 && !controller.isUnlocked(topic.id)) {
      final isBn = controller.isBangla;
      final approved = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(isBn ? 'টপিক আনলক' : 'Unlock topic'),
          content: Text(
            isBn
                ? 'এই টপিকটি খুলতে ${topic.cost} কয়েন লাগবে। আপনার কাছে ${controller.coins} কয়েন আছে।'
                : 'This topic costs ${topic.cost} coins. You have ${controller.coins} coins.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text(isBn ? 'বাতিল' : 'Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(isBn ? 'আনলক' : 'Unlock'),
            ),
          ],
        ),
      );
      if (approved != true || !context.mounted) return;
      final success = await controller.unlockTopic(topic.id, topic.cost);
      if (!success && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(isBn ? 'পর্যাপ্ত কয়েন নেই' : 'Not enough coins'),
            action: SnackBarAction(
              label: isBn ? 'কয়েন' : 'Coins',
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => CoinsScreen(controller: controller)),
              ),
            ),
          ),
        );
        return;
      }
    }
    if (!context.mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => TopicScreen(controller: controller, topic: topic),
      ),
    );
  }
}
