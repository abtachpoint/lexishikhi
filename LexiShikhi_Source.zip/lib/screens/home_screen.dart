import 'package:flutter/material.dart';

import '../models/learning_module.dart';
import '../services/app_controller.dart';
import '../services/data_repository.dart';
import 'coins_screen.dart';
import 'module_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final isBn = controller.isBangla;
    return Scaffold(
      appBar: AppBar(
        title: const Text('LexiShikhi'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ActionChip(
              avatar: const Text('🪙'),
              label: Text('${controller.coins}'),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => CoinsScreen(controller: controller),
                ),
              ),
            ),
          ),
          IconButton(
            tooltip: isBn ? 'সেটিংস' : 'Settings',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => SettingsScreen(controller: controller),
              ),
            ),
          ),
        ],
      ),
      body: FutureBuilder<List<LearningModule>>(
        future: DataRepository.loadModules(),
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError || !snapshot.hasData) {
            return Center(
              child: Text(isBn ? 'কনটেন্ট লোড করা যায়নি' : 'Could not load content'),
            );
          }

          final modules = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isBn ? 'ইংরেজি শেখা হোক সহজ' : 'Learn English with confidence',
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      isBn
                          ? 'অফলাইনে পড়ো, প্রয়োজনীয় টপিক আনলক করো এবং নিজের গতিতে প্র্যাকটিস করো।'
                          : 'Study offline, unlock useful topics, and practice at your own pace.',
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              Text(
                isBn ? 'স্টাডি মডিউল' : 'Study modules',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 12),
              ...modules.map((module) => _ModuleCard(
                    module: module,
                    isBn: isBn,
                    controller: controller,
                  )),
            ],
          );
        },
      ),
    );
  }
}

class _ModuleCard extends StatelessWidget {
  const _ModuleCard({
    required this.module,
    required this.isBn,
    required this.controller,
  });

  final LearningModule module;
  final bool isBn;
  final AppController controller;

  IconData get icon {
    switch (module.id) {
      case 'paragraph':
        return Icons.subject;
      case 'composition':
        return Icons.menu_book_outlined;
      case 'story':
        return Icons.auto_stories_outlined;
      case 'dialogue':
        return Icons.forum_outlined;
      case 'letters_applications':
        return Icons.mail_outline;
      case 'emails':
        return Icons.alternate_email;
      case 'reports':
        return Icons.description_outlined;
      case 'grammar':
        return Icons.spellcheck;
      case 'vocabulary':
        return Icons.translate;
      case 'translation':
        return Icons.g_translate;
      case 'practice':
        return Icons.quiz_outlined;
      default:
        return Icons.school_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => ModuleScreen(
                controller: controller,
                module: module,
              ),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.secondaryContainer,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(icon),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isBn ? module.titleBn : module.titleEn,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w800,
                            ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        isBn ? module.descriptionBn : module.descriptionEn,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 5),
                      Text(
                        isBn
                            ? '${module.topics.length}টি টপিক'
                            : '${module.topics.length} topics',
                        style: Theme.of(context).textTheme.labelMedium,
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
