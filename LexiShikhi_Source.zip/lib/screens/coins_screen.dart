import 'package:flutter/material.dart';

import '../services/app_controller.dart';

class CoinsScreen extends StatelessWidget {
  const CoinsScreen({super.key, required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final isBn = controller.isBangla;
    return Scaffold(
      appBar: AppBar(title: Text(isBn ? 'কয়েন' : 'Coins')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              children: [
                const Text('🪙', style: TextStyle(fontSize: 42)),
                Text(
                  '${controller.coins}',
                  style: Theme.of(context).textTheme.displaySmall?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
                Text(isBn ? 'বর্তমান কয়েন' : 'Current coins'),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.card_giftcard)),
              title: Text(isBn ? 'ডেইলি বোনাস' : 'Daily bonus'),
              subtitle: Text(isBn ? 'প্রতিদিন +5 কয়েন' : '+5 coins once per day'),
              trailing: FilledButton(
                onPressed: controller.canClaimDailyBonus
                    ? () async {
                        final claimed = await controller.claimDailyBonus();
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                claimed
                                    ? (isBn ? '5 কয়েন যোগ হয়েছে' : '5 coins added')
                                    : (isBn ? 'আজকের বোনাস নেওয়া হয়েছে' : 'Today’s bonus is already claimed'),
                              ),
                            ),
                          );
                        }
                      }
                    : null,
                child: Text(isBn ? 'নাও' : 'Claim'),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.play_circle_outline)),
              title: Text(isBn ? 'Rewarded ad' : 'Rewarded ad'),
              subtitle: Text(
                isBn
                    ? 'শুধু ব্যবহারকারী চাইলে দেখবে। AdMob ID যোগ করার পর চালু হবে।'
                    : 'Optional only. It will be enabled after adding an AdMob ID.',
              ),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.shopping_bag_outlined)),
              title: Text(isBn ? 'Coin pack / IAP' : 'Coin packs / IAP'),
              subtitle: Text(
                isBn
                    ? 'Play Console product ID যোগ করার পর purchase চালু হবে।'
                    : 'Purchases will be enabled after Play Console product IDs are added.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
