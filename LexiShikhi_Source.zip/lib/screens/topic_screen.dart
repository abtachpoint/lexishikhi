import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/learning_module.dart';
import '../services/app_controller.dart';

class TopicScreen extends StatelessWidget {
  const TopicScreen({
    super.key,
    required this.controller,
    required this.topic,
  });

  final AppController controller;
  final LearningTopic topic;

  @override
  Widget build(BuildContext context) {
    final isBn = controller.isBangla;
    return Scaffold(
      appBar: AppBar(
        title: Text(isBn ? topic.titleBn : topic.titleEn),
        actions: [
          IconButton(
            tooltip: isBn ? 'কপি' : 'Copy',
            icon: const Icon(Icons.copy_outlined),
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: topic.bodyEn));
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(isBn ? 'কপি হয়েছে' : 'Copied')),
                );
              }
            },
          ),
        ],
      ),
      body: SelectionArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 30),
          children: [
            Text(
              topic.titleEn,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Text(
                topic.bodyEn,
                style: const TextStyle(fontSize: 16, height: 1.65),
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.secondaryContainer,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isBn ? 'সহজ টিপস' : 'Study tip',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 6),
                  Text(isBn ? topic.tipBn : 'Read the sample, notice the structure, then rewrite it in your own words.'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
