import 'package:flutter/material.dart';

import '../services/app_controller.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final isBn = controller.isBangla;
    return Scaffold(
      appBar: AppBar(title: Text(isBn ? 'সেটিংস' : 'Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            isBn ? 'ইন্টারফেস ভাষা' : 'Interface language',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
          ),
          const SizedBox(height: 10),
          RadioListTile<String>(
            value: 'bn',
            groupValue: controller.language,
            title: const Text('বাংলা'),
            onChanged: (value) {
              if (value != null) controller.setLanguage(value);
            },
          ),
          RadioListTile<String>(
            value: 'en',
            groupValue: controller.language,
            title: const Text('English'),
            onChanged: (value) {
              if (value != null) controller.setLanguage(value);
            },
          ),
          const Divider(height: 30),
          ListTile(
            leading: const Icon(Icons.offline_bolt_outlined),
            title: Text(isBn ? 'অফলাইন কনটেন্ট' : 'Offline content'),
            subtitle: Text(
              isBn
                  ? 'মূল স্টাডি কনটেন্ট অ্যাপের ভেতরেই রাখা হয়েছে।'
                  : 'Core study content is bundled inside the app.',
            ),
          ),
          ListTile(
            leading: const Icon(Icons.ads_click_outlined),
            title: Text(isBn ? 'বিজ্ঞাপন' : 'Ads'),
            subtitle: Text(
              isBn
                  ? 'অটোমেটিক বিজ্ঞাপন নেই। Rewarded ad পরে আলাদাভাবে চালু করা যাবে।'
                  : 'No automatic ads. Rewarded ads can be enabled later.',
            ),
          ),
        ],
      ),
    );
  }
}
