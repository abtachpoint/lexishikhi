/// Monetization is intentionally disabled in the starter build.
/// Add real Play Console product IDs / AdMob IDs before enabling these flags.
class MonetizationConfig {
  static const bool enableIap = false;
  static const bool enableRewardedAds = false;

  static const List<String> plannedCoinProductIds = <String>[
    'coins_051',
    'coins_101',
    'coins_201',
    'coins_301',
    'coins_401',
    'coins_1001_mega',
  ];
}
