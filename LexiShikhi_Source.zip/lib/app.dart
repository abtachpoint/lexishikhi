import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'services/app_controller.dart';

class LexiShikhiApp extends StatelessWidget {
  const LexiShikhiApp({super.key, required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'LexiShikhi',
          theme: ThemeData(
            useMaterial3: true,
            colorSchemeSeed: const Color(0xFF236B5B),
            scaffoldBackgroundColor: const Color(0xFFF7FAF9),
            appBarTheme: const AppBarTheme(centerTitle: false),
          ),
          home: HomeScreen(controller: controller),
        );
      },
    );
  }
}
