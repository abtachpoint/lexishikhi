import 'dart:convert';

import 'package:flutter/services.dart';

import '../models/learning_module.dart';

class DataRepository {
  static Future<List<LearningModule>> loadModules() async {
    final raw = await rootBundle.loadString('assets/data/learning_content.json');
    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    final modules = decoded['modules'] as List<dynamic>;
    return modules
        .map((item) => LearningModule.fromJson(item as Map<String, dynamic>))
        .toList();
  }
}
