import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppController extends ChangeNotifier {
  static const _coinsKey = 'coins';
  static const _languageKey = 'language';
  static const _unlockedKey = 'unlocked_topics';
  static const _dailyBonusKey = 'daily_bonus_date';

  int _coins = 20;
  String _language = 'bn';
  Set<String> _unlocked = <String>{};
  String? _lastBonusDate;

  int get coins => _coins;
  bool get isBangla => _language == 'bn';
  String get language => _language;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _coins = prefs.getInt(_coinsKey) ?? 20;
    _language = prefs.getString(_languageKey) ?? 'bn';
    _unlocked = (prefs.getStringList(_unlockedKey) ?? <String>[]).toSet();
    _lastBonusDate = prefs.getString(_dailyBonusKey);
  }

  bool isUnlocked(String topicId) => _unlocked.contains(topicId);

  Future<bool> unlockTopic(String topicId, int cost) async {
    if (isUnlocked(topicId)) return true;
    if (_coins < cost) return false;
    _coins -= cost;
    _unlocked.add(topicId);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_coinsKey, _coins);
    await prefs.setStringList(_unlockedKey, _unlocked.toList());
    notifyListeners();
    return true;
  }

  Future<void> setLanguage(String language) async {
    if (language != 'bn' && language != 'en') return;
    _language = language;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_languageKey, language);
    notifyListeners();
  }

  bool get canClaimDailyBonus {
    final now = DateTime.now();
    final today = '${now.year}-${now.month}-${now.day}';
    return _lastBonusDate != today;
  }

  Future<bool> claimDailyBonus() async {
    if (!canClaimDailyBonus) return false;
    final now = DateTime.now();
    final today = '${now.year}-${now.month}-${now.day}';
    _coins += 5;
    _lastBonusDate = today;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_coinsKey, _coins);
    await prefs.setString(_dailyBonusKey, today);
    notifyListeners();
    return true;
  }
}
