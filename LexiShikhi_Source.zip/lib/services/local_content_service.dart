import 'dart:convert';
import 'package:flutter/services.dart';

class LocalContentService {
  static Future<List<dynamic>> loadList(String fileName) async {
    final raw = await rootBundle.loadString('assets/data/$fileName');
    final data = jsonDecode(raw);
    if (data is List) return data;
    throw FormatException('$fileName must contain a JSON list');
  }

  static Future<List<dynamic>> loadParagraphs() => loadList('paragraphs.json');
  static Future<List<dynamic>> loadCompositions() => loadList('compositions.json');
  static Future<List<dynamic>> loadStories() => loadList('stories.json');
  static Future<List<dynamic>> loadDialogues() => loadList('dialogues.json');
  static Future<List<dynamic>> loadLettersApplications() => loadList('letters_applications.json');
  static Future<List<dynamic>> loadEmails() => loadList('emails.json');
  static Future<List<dynamic>> loadReports() => loadList('reports.json');
  static Future<List<dynamic>> loadGrammar() => loadList('grammar.json');
  static Future<List<dynamic>> loadVocabulary() => loadList('vocabulary.json');
  static Future<List<dynamic>> loadTranslation() => loadList('translation.json');
  static Future<List<dynamic>> loadPractice() => loadList('practice.json');
  static Future<List<dynamic>> loadCategories() => loadList('categories.json');
  static Future<List<dynamic>> loadWritingCategories() => loadList('writing_categories.json');
}